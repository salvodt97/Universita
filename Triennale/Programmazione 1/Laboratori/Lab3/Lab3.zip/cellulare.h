#ifndef CELLULARE_H
#define CELLULARE_H

#include "oggetto.h"
namespace Mynamespace { 

class cellulare: public oggetto{
        
friend ostream& operator<<(ostream&, const cellulare&);
friend istream& operator>>(istream&, cellulare&);
        private: 
                char*modello;
                float costo;
        public:
            cellulare(): oggetto(), modello(new char[1]), costo(0) {strcpy(modello,"");}
            cellulare(const int, const char*, const char*, const float);
            cellulare(const cellulare&);
            ~cellulare() {delete[] modello;};
            
            void set_modello(const char*);
            void set_costo(const float);
            
            
            const char* get_modello()const {return modello;};
            const float get_costo()const {return costo;};
            
            const cellulare & operator=(const cellulare&);
            
            bool operator==(const cellulare&)const;
            
                
    };
}//namespace
#endif
