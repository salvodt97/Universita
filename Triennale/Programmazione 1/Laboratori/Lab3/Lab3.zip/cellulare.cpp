
#include "cellulare.h"
namespace Mynamespace {

        
ostream& operator<<(ostream&out, const cellulare& C){
       return out<<(oggetto&)C << ' '<<C.modello << ' '<<C.costo;
    }
    
istream& operator>>(istream& in, cellulare & C){
    char temp[100];
	in>>(oggetto&)C >> temp >> C.costo;
    C.set_modello(temp);
    return in;
    }

cellulare::cellulare(const int c, const char* d, const char* m, const float cos):oggetto(c,d){  
        modello=new char[strlen(m)+1];
        strcpy(modello,m);
        costo=cos;       
}
                
cellulare::cellulare(const cellulare& C ):oggetto(C){     
        modello = new char[strlen(C.modello)+1];
        strcpy(modello, C.modello);
        costo=C.costo;
}
            
            
void cellulare::set_modello(const char* m){  
        modello=new char[strlen(m)+1];
        strcpy(modello,m); 
}

void cellulare::set_costo(const float c){costo=c;}
            
const cellulare& cellulare::operator=(const cellulare& C ){
                            
        if(this != &C){                   
          oggetto::operator=(C);
          set_modello(C.modello);
          set_costo(C.costo);                                          
        }
       return *this;
}

            
bool cellulare::operator==(const cellulare& C)const{  
     return(oggetto::operator==(C) && !(strcmp(modello,C.modello) && costo==C.costo));
}
            
                
}    //namespace
