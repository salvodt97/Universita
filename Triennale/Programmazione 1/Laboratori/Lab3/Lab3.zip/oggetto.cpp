#include "oggetto.h"

namespace Mynamespace {
	
ostream& operator<<(ostream& out, const oggetto& O){
    return out<< O.codice << ' ' << O.descrizione;
    }
    
istream&operator>>(istream& in, oggetto& O){
        char temp[DIM_S];
        in >> O.codice >> temp;
        O.set_descrizione(temp);
        return in;   
    }
    
oggetto::oggetto(const int c, const char* d){
        codice=c;
        descrizione= new char[strlen(d)+1];
        strcpy(descrizione,d);
    }
    
oggetto::oggetto(const oggetto& O){
        codice=O.codice;
        descrizione= new char[strlen(O.descrizione)+1];
        strcpy(descrizione,O.descrizione);
    }
    
oggetto::~oggetto(){       
        delete[] descrizione;
    }

            
void oggetto::set_codice(const int c){  
        codice=c;
    }
    
void oggetto::set_descrizione(const char* d){
        if(descrizione) delete[] descrizione;
        descrizione=new char[strlen(d)+1];
        strcpy(descrizione,d);
    }
      
const oggetto& oggetto::operator=(const oggetto& O){
        
        if(this != &O){     
                    set_codice(O.codice);
                    set_descrizione(O.descrizione);
            }
            return *this;
    }    
            
            
bool oggetto::operator==(const oggetto& O)const{
        return(codice==O.codice && !(strcmp(descrizione,O.descrizione)));
    }
    
}//namespace
