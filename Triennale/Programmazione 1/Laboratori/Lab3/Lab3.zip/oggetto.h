#ifndef OGGETTO_H
#define OGGETTO_H

#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

namespace Mynamespace { 
 
const int DIM_S=100;

class oggetto{
    
    friend ostream& operator<<(ostream&, const oggetto&);
    friend istream& operator>>(istream&, oggetto&);
        
        protected: 
            int codice;
            char* descrizione;
        public:
            oggetto(): codice(0), descrizione(new char [1])
			           {strcpy(descrizione,"");}
            oggetto(const int, const char*);
            oggetto(const oggetto&);
            ~oggetto();
            
            void set_codice(const int);
            void set_descrizione(const char*);
            
            int get_codice()const {return codice;};
            const char* get_descrizione()const {return descrizione;};
           
            const oggetto & operator=(const oggetto&);
            bool operator==(const oggetto&)const;          
    };
} //namespace
#endif
