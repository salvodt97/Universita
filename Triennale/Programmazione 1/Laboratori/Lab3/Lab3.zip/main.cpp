#include <iostream>
#include <stdlib.h>

#include "libro.h"
#include "cellulare.h"

using namespace std;
using namespace Mynamespace;

int main(int argc, char *argv[])
{
    cout<<"\n\n***TEST OGGETTO***\n\n";
    
    oggetto O1 (234,"si usa per scrivere");
    oggetto O2;
    
    cout<<"\n Inserisci oggetto O2: ";
    cin>>O2;
    
    cout<<"\n Gli elementi inseriti sono: ";
    cout<<O1 << endl;
    cout<<O2 << endl;
    
    cout<<"\n\n***TEST LIBRO***\n\n";
    
    libro L1 (264,"ha una copertina e tante pagine", "Orgoglio e pregiudizio", 560);
    libro L2;
    
    cout<<"\n Inserisci libro L2: ";
    cin>>L2;
    
    cout<<"\n Gli elementi inseriti sono: ";
    cout<<L1 <<endl;
    cout<<L2 <<endl;
    
    cout<<"\n\n***TEST CELLULARE***\n\n";
    
    cellulare C1 (234,"si usa per chiamare","samsung",500);
    cellulare C2;
    
    cout<<"\n Inserisci oggetto O2: ";
    cin>>C2;
    
    cout<<"\n Gli elementi inseriti sono: ";
    cout<<C1 <<endl;
    cout<<C2 <<endl;
    
  
  system("PAUSE");	
  return 0;
}
