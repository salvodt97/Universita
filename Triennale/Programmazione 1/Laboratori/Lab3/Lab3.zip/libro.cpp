#include "libro.h"

namespace Mynamespace {
        
ostream& operator<<(ostream&out, const libro& L){
       return out<<(oggetto&)L << ' '<< L.titolo << ' '<<L.npagine;
    }
    
istream& operator>>(istream& in, libro& L){
        char temp[100];
        in>>(oggetto&)L >> temp >> L.npagine;
        L.set_titolo(temp);
        return in;
    }

libro::libro(const int c, const char* d, const char* t, const int np):oggetto(c,d){         
        titolo=new char[strlen(t)+1];
        strcpy(titolo,t);
        npagine=np;                
}
                
libro::libro(const libro& L ):oggetto(L){                    
        titolo = new char[strlen(L.titolo)+1];
        strcpy(titolo, L.titolo);
        npagine=L.npagine;
}
                    
void libro::set_titolo(const char* t){
      if(titolo) delete [] titolo;
      titolo=new char[strlen(t)+1];
      strcpy(titolo,t); 
}

void libro::set_npagine(const int np) {npagine=np;}
            
const libro&libro::operator=(const libro& L ){   
        if(this != &L){                 
           oggetto::operator=(L);
           set_titolo(L.titolo);
           set_npagine(L.npagine);                                          
        }
        return *this;
}
            
bool libro::operator==(const libro& L)const{
    return(oggetto::operator==(L) && !(strcmp(titolo,L.titolo) && npagine==L.npagine));          
}
 } //namespace   

