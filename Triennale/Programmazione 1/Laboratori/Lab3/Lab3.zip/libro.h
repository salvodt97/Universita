#ifndef LIBRO_H
#define LIBRO_H

#include "oggetto.h"
namespace Mynamespace {
class libro: public oggetto{
        
friend ostream& operator<<(ostream&, const libro&);
friend istream& operator>>(istream&, libro&);
        private: 
            char* titolo;
            int npagine;
        public:
            libro(): oggetto(), titolo(new char[1]), npagine(0) {strcpy(titolo,"");}
            libro(const int, const char*, const char*, const int);
            libro(const libro&);
            ~libro() {delete[] titolo;};
            
            void set_titolo(const char*);
            void set_npagine(const int);
            
            
            const char* get_titolo()const {return titolo;}
            const int get_npagine()const {return npagine;}
            
            const libro& operator=(const libro&);
            
            bool operator==(const libro&)const;
            
                
    };
} //namespace
#endif 
