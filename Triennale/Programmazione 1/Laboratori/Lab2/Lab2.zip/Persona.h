#ifndef _PERSONA_H
#define _PERSONA_H

#include <iostream>
#include <cstring>
#include <string>
using namespace std;

//classe persona prima versione: esempio di classe
//con estensione dinamica e costruttore di copia
const int CF_MAX=17;
const int sizeBuffer=200;

class Persona {
	
	private:
	string Nome;
	char * Cognome;
	char CF[CF_MAX];
	int Eta;
	
	public:
		Persona();
		Persona(const string, const char *, const char *, const int);
		Persona(const Persona &);  //costruttore di copia
	//	const Persona & operator=(const Persona &); prossima lezione!!!!
		void print(ostream &) const;
		void read();
		bool checkCF() const;
		bool checkEta() const;
		void set_C(const char *);
		void set_N(const string);
		void set_E(const int);
		void set_CF(const char *);
		const char * get_C() const {return Cognome;}// torna un puntatore!
		string get_N() const {return Nome;}  // const string & get_N() const; 
		const char * get_CF() const {return CF;} // torna un puntatore!
		int get_E() const {return Eta;}
		~Persona(); //distruttore
};
#endif
