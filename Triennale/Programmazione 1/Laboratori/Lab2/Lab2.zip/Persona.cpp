#include "Persona.h"

Persona::Persona(){
	Nome="";
	Cognome=new char[1];
	strcpy(Cognome, "");
	strcpy(CF, "****************");	
	Eta=0;
}

Persona::Persona(const string N, const char * C, const char * Codice, const int E){
	Nome=N;
	Cognome=new char[strlen(C)+1];
	strcpy(Cognome, C);
	strcpy(CF, Codice);
	Eta=E;
}

Persona::Persona(const Persona & P){
	Nome=P.Nome;
	Cognome=new char[strlen(P.Cognome)+1];
	strcpy(Cognome, P.Cognome);
	strcpy(CF, P.CF);
	Eta=P.Eta;
}

Persona::~Persona(){
	cout << "distruttore";
	delete [] Cognome;
}



void Persona::set_C(const char * C){
	if(Cognome) delete [] Cognome;  // if pu� essere omesso se il ptr non � mai null
	Cognome=new char[strlen(C)+1];
	strcpy(Cognome, C);
}


void Persona::set_CF(const char * Codice){
	strcpy(CF, Codice);
}


void Persona::set_N(string N){
	Nome=N;
}

void Persona::set_E(const int E){
	Eta=E;
}

void Persona::print(ostream & out) const{
   out << Nome << ' ' << Cognome << ' ' << CF << ' ' << Eta;
}

void Persona::read() {
	// if pu� essere omesso se il ptr non � mai null
	char buffer[sizeBuffer];
	cout << "inserisci il nome:" << endl;
	cin >> Nome;
	cin.ignore();
	cout << "inserisci il cognome:" << endl;
	if(Cognome) delete [] Cognome;
	cin.getline(buffer,sizeBuffer);
	Cognome=new char[strlen(buffer)+1];
	strcpy(Cognome,buffer);
	cout << "inserisci il CF:" << endl;
//	cin.ignore();
	cin.getline(CF,sizeBuffer);
	cout << "inserisci l'eta:" << endl;
	cin>> Eta;
}

bool Persona::checkCF() const {
bool ok=true;
int i=0;

while(i<CF_MAX-1 && ok)
  if (!(CF[i]>='0' && CF[i]<='9') && !(CF[i]>='a' && CF[i]<='z') && !(CF[i]>='A' && CF[i]<='Z'))
      ok=false;
  else i++;   
   
return (strlen(CF)==16 && ok);

}


bool Persona::checkEta() const{
	return (Eta>=0 && Eta<=120);
}
