#include <iostream>
#include "Persona.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	
	Persona p; // costruttore senza argomenti
	Persona p1("Mario", "Rossi", "RSSMRR38P65F839", 10); //costruttore con argomenti
	Persona p2=p1; //costruttore di copia
	Persona p3("Laura", "Bianchi","LRRBNC*8P65F839X", 22);
	
	

	cout << "p1: " << endl;
	p1.print(cout);
	cout << "\n";
	cout << "p2: " << endl;
	p2.print(cout);
	cout << "\n";
	cout << "p3: " << endl;
	p3.print(cout);
	cout << "\n";
	
	p2.set_C("Roberti");
	cout << p2.get_C() << endl;
    cout << "\n";
	cout << "inserire i dati di una persona: " << endl;
	p.read();
	cout << "p: " << endl;
	p.print(cout);
	cout << "\n";
	if(!p1.checkCF()) cout << p1.get_C() << ':' << "Codice fiscale errato" << endl;
	else cout << p1.get_C() << ':' << "Codice fiscale giusto" << endl;
	if(!p3.checkCF()) cout << p3.get_C() << ':' << "Codice fiscale errato" << endl;
	else cout << p3.get_C() << ':' << "Codice fiscale giusto" << endl;
	if(!p.checkCF()) cout << p.get_C() << ':' << "Codice fiscale errato" << endl;
	else cout << p.get_C() << ':' << "Codice fiscale giusto"<< endl;
	
	return 0;
}
